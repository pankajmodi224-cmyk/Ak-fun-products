
export default function App() {
  const products = [
    {
      id: 1,
      name: 'Kids Bottle',
      price: '₹499',
      image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 2,
      name: 'Lunch Box',
      price: '₹799',
      image: 'https://images.unsplash.com/photo-1585238342024-78d387f4a707?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 3,
      name: 'School Bag',
      price: '₹1299',
      image: 'https://images.unsplash.com/photo-1581605405669-fcdf81165afa?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 4,
      name: 'Trolley Bag',
      price: '₹2499',
      image: 'https://images.unsplash.com/photo-1565026057447-bc90a3dceb87?q=80&w=1200&auto=format&fit=crop'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-black text-white px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <img
            src="/logo.jpeg"
            alt="Logo"
            className="w-14 h-14 rounded-full object-cover border-2 border-white"
          />
          <h1 className="text-2xl font-bold">@K Fun Products</h1>
        </div>

        <a
          href="https://wa.me/919756885521"
          target="_blank"
          className="bg-green-500 px-5 py-2 rounded-full font-semibold"
        >
          WhatsApp
        </a>
      </nav>

      <section className="bg-gradient-to-r from-pink-500 to-orange-400 text-white text-center py-20 px-6">
        <h2 className="text-5xl font-bold mb-6">
          Fun Products For Everyone
        </h2>

        <p className="text-xl max-w-2xl mx-auto mb-8">
          Bottles, Lunch Boxes, Bags, Trolley Bags, Baby Fun Products and much more.
        </p>

        <a
          href="https://wa.me/919756885521"
          target="_blank"
          className="bg-black px-8 py-4 rounded-full text-lg font-bold"
        >
          Order on WhatsApp
        </a>
      </section>

      <section className="py-16 px-6">
        <h3 className="text-4xl font-bold text-center mb-12">
          Featured Products
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-3xl overflow-hidden shadow-lg hover:scale-105 transition"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-64 object-cover"
              />

              <div className="p-5">
                <h4 className="text-2xl font-bold mb-2">{product.name}</h4>

                <p className="text-green-600 text-xl font-semibold mb-4">
                  {product.price}
                </p>

                <button className="w-full bg-black text-white py-3 rounded-xl">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white py-14 px-6">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gray-100 p-6 rounded-3xl text-center shadow">
            <h4 className="text-2xl font-bold mb-3">Fast Delivery</h4>
            <p>Delivery available across India.</p>
          </div>

          <div className="bg-gray-100 p-6 rounded-3xl text-center shadow">
            <h4 className="text-2xl font-bold mb-3">Secure Payment</h4>
            <p>UPI, Cards and COD available.</p>
          </div>

          <div className="bg-gray-100 p-6 rounded-3xl text-center shadow">
            <h4 className="text-2xl font-bold mb-3">24/7 Support</h4>
            <p>Contact us anytime on WhatsApp.</p>
          </div>
        </div>
      </section>

      <footer className="bg-black text-white text-center py-8">
        <h4 className="text-3xl font-bold mb-3">@K Fun Products</h4>

        <p>WhatsApp / Message:</p>
        <p>9756885521 / 8433140887</p>

        <p className="mt-4">
          © 2026 @K Fun Products. All rights reserved.
        </p>
      </footer>

      <a
        href="https://wa.me/919756885521"
        target="_blank"
        className="fixed bottom-5 right-5 bg-green-500 text-white px-5 py-3 rounded-full shadow-2xl font-bold"
      >
        WhatsApp Us
      </a>
    </div>
  )
}
